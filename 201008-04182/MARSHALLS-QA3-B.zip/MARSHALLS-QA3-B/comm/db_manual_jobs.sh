#!/bin/ksh
#############################################################################
# $Id: db_manual_jobs.sh,v 1 2013/08/05 jeberlin
#############################################################################
#
# SCRIPT:       db_manual_jobs.sh
#
# PURPOSE:      A script invoked by cron on a schedule to manually run several jobs.
# INPUT PARMS:  
#               $1 db name
#               $2 script name
#
# NOTES:        Needed until we create a new shared file system for db directories.
#               
#
# PENDING:      None
#
#############################################################################
#-----------------------------------------------------------------
# Assign input parms
#-----------------------------------------------------------------
dbname=$1
scriptname=$2
#-----------------------------------------------------------------
# Invoke script to capture input parm info and setup environment.
# To override the /u00/app default the cron job will need to be
# modified to set the DIR_ORAUNIX_BASE variable
# Otherwise set the variable to the default value here
#-----------------------------------------------------------------

. /export/MARSHALLS-QA3-B/comm/set_ora_env.sh

#-----------------------------------------------------------------
# Set the script location.
scripts="/export/MARSHALLS-QA3-B/sql"
#-----------------------------------------------------------------
upass="tjx_catfeed/atgtjx99"
ORACLE_SID=$dbname
export ORACLE_SID
sqlplus $upass  < $scripts/$scriptname > /tmp/$scriptname.log
#-----------------------------------------------------------------
chmod -R 755 /export/MARSHALLS-QA3-B/tjx-feed/*
