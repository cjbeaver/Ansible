export ORACLE_SID=$1
export ORACLE_HOME=/u01/app/oracle/product/12.1.0/dbhome_1
PATH=$ORACLE_HOME/bin:$PATH
