set serverout on
select INSTANCE_NAME from v$instance;

declare
begin
  DBMS_SCHEDULER.RUN_JOB ('TJX_TYPE_AHEAD_EXPORT', TRUE);
end;
/
