host ls -l /export/MARSHALLS-QA3-B/tjx-feed/import/drop
host ls -l /export/MARSHALLS-QA3-B/tjx-feed/import/bad
set serverout on
select INSTANCE_NAME from v$instance;
begin
DBMS_SCHEDULER.RUN_JOB ('tjx_inventory_import', true);
end;
/
