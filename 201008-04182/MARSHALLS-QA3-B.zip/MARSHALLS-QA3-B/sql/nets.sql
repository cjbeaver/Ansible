host ls -l /export/MARSHALLS-QA3-B/tjx-feed/import/drop
host ls -l /export/MARSHALLS-QA3-B/tjx-feed/import/bad
select INSTANCE_NAME from v$instance;
begin
DBMS_SCHEDULER.RUN_JOB ('TJX_NETS_MASTER_IMPORT', TRUE);
  commit;
  dbms_session.close_database_link('MSSQL');
 
  exception
  when others then
  dbms_session.close_database_link('MSSQL');
end;
/
