. /export/MARSHALLS-QA3-B/comm/set_ora_env.sh $ORACLE_SID_UPGRADE_QA3B
sqlplus /nolog<<EOF
conn /as sysdba
set pages 500 lines 222
set echo on

alter session set current_schema=TJX_CORE;

spool /export/MARSHALLS-QA3-B/tjx-feed/order_check/archive/order_log/order_check_on_production_$date.log
@/export/MARSHALLS-QA3-B/tjx-core/order_check/select_order.sql
spool off
exit
EOF

chmod 777 /export/MARSHALLS-QA3-B/tjx-feed/order_check/archive/order_log/order*.log

find /export/MARSHALLS-QA3-B/tjx-feed/order_check/archive/order_log -name "distinct_order*" -mtime +7 -exec rm -rf {} \;
