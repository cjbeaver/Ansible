col order_id heading "Issues with commerce item"

select distinct (do.order_id) from tjx_core.dcspp_order do join tjx_core.dcspp_item di on do.order_id=di.order_ref and do.state='INCOMPLETE' and di.commerce_item_id in(select commerce_item_id from (select commerce_item_id, count(relationship_id) from tjx_core.dcspp_shipitem_rel group by commerce_item_id having count(distinct relationship_id)>1));
