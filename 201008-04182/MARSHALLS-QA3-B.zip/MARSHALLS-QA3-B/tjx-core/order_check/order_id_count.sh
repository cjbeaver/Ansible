. /export/MARSHALLS-QA3-B/comm/set_ora_env.sh $ORACLE_SID_UPGRADE_QA3B

date=`date +%Y%m%d_%H:%M:%S`
sqlplus /nolog<<EOF
conn /as sysdba
set pages 500 lines 222
--select name,open_mode,controlfile_type from v\$database;
--select distinct a.sid,b.serial# from v\$mystat a, v\$session b where a.sid = b.sid;
set echo on define off lines 333

--alter session set current_schema=TJX_CORE;
spool /export/MARSHALLS-QA3-B/tjx-feed/order_count/archive/order_id_count_on_production_$date.log
@/export/MARSHALLS-QA3-B/tjx-feed/order_count/order_id_count.sql
spool off
exit
EOF

chmod 777 /export/MARSHALLS-QA3-B/tjx-feed/order_count/archive/order_id_count_*.log
chmod 777 /export/MARSHALLS-QA3-B/tjx-feed/order_count/order_id_count.out

find /export/MARSHALLS-QA3-B/tjx-feed/order_count/archive/ -name "order_id_count_on_production_*.log" -mtime +7 -exec rm -rf {} \;
