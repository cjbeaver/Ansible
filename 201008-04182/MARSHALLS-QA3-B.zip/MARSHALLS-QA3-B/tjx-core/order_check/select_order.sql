col order_id heading "dcspp_order_rel not getting updated" 


select order_id  from tjx_core.dcspp_order where state='INCOMPLETE' and order_id in(select order_ref from tjx_core.dcspp_relationship where relationship_id not in(select relationships from tjx_core.dcspp_order_rel ));
