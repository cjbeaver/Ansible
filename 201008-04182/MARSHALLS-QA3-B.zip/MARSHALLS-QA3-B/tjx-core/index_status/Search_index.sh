. /export/MARSHALLS-QA3-B/comm/set_ora_env.sh $ORACLE_SID_UPGRADE_QA3B

date=`date +%Y%m%d_%H:%M:%S`
echo $date
sqlplus /nolog<<EOF
conn /as sysdba
set pages 500 lines 222
select name,open_mode,controlfile_type from v\$database;
select distinct a.sid,b.serial# from v\$mystat a, v\$session b where a.sid = b.sid;
set echo on define off lines 333

alter session set current_schema=TJX_CORE;

spool /export/MARSHALLS-QA3-B/tjx-core/index_status/archive/Search_index_failed_on_production_$date.log
@/export/MARSHALLS-QA3-B/tjx-core/index_status/select_index.sql
spool off
exit
EOF

chmod 664 /export/MARSHALLS-QA3-B/tjx-core/index_status/archive/Search_index_*.log
chmod 664 /export/MARSHALLS-QA3-B/tjx-core/index_status/Search_index.out

find /export/MARSHALLS-QA3-B/tjx-core/index_status/archive/ -name "Search_index_failed_on_production_*.log" -mtime +7 -exec rm -rf {} \;
