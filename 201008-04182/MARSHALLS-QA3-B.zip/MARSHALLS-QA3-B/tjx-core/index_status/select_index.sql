col RESULT heading "TJX-Search index failed in production"


SELECT CASE WHEN SUM(SUCCESS) < 2 THEN 'FAILED' ELSE 'SUCCESS' END AS RESULT
FROM TJX_CORE.srch_end_job where start_time in
((Select max(start_time)from TJX_CORE.srch_end_job where server_id='1122866-app1.qa3.marshalls.com+tjx-stage'),(Select max(start_time)from TJX_CORE.srch_end_job where server_id='1122866-app1.qa3.marshalls.com+tjx-search-index'));
